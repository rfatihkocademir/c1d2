// frontend/src/components/ScenarioArea.js
import React from 'react';
import { Droppable, Draggable } from 'react-beautiful-dnd';
import DraggableItem from './DraggableItem';

const ScenarioArea = ({ scenario, onRemoveAction, onUpdateActionParams, getPlaceholderText }) => {
  return (
    <div className="scenario-area" style={{ flex: '2', border: '2px solid #28a745', borderRadius: '8px' }}>
      <div className="card shadow-sm h-100">
        <div className="card-header bg-success text-white">
          <h5 className="mb-0">Senaryo</h5>
        </div>
        <Droppable droppableId="droppable-scenario">
          {(provided) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className="card-body"
              style={{ maxHeight: '800px', overflowY: 'auto' }}
            >
              {scenario.length > 0 ? (
                scenario.map((item, index) => (
                  <DraggableItem
                    key={index}
                    index={index}
                    item={item}
                    onRemoveAction={onRemoveAction}
                    onUpdateActionParams={onUpdateActionParams}
                    getPlaceholderText={getPlaceholderText}
                  />
                ))
              ) : (
                <p className="text-center text-muted">Senaryo oluşturmak için işlemleri buraya sürükleyin.</p>
              )}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </div>
    </div>
  );
};

export default ScenarioArea;
