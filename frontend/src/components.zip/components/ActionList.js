// frontend/src/components/ActionList.js
import React from 'react';
import ActionCard from './ActionCard';

const ActionList = ({ actions, dropRef }) => {
  return (
    <div ref={dropRef} className="action-cards" style={{ flex: '1', marginRight: '20px', border: '2px solid #007bff', borderRadius: '8px' }}>
      <div className="card shadow-sm h-100">
        <div className="card-header bg-primary text-white">
          <h5 className="mb-0">İşlemler</h5>
        </div>
        <div className="card-body" style={{ maxHeight: '800px', overflowY: 'auto' }}>
          {actions.map((action, index) => (
            <ActionCard key={index} action={action} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ActionList;
