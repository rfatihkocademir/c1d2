// frontend/src/components/DraggableItem.js
import React from 'react';
import { Draggable } from 'react-beautiful-dnd';

const DraggableItem = ({ index, item, onRemoveAction, onUpdateActionParams, getPlaceholderText }) => {
  return (
    <Draggable draggableId={`draggable-${index}`} index={index}>
      {(provided) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          style={{ marginBottom: '10px', ...provided.draggableProps.style }}
        >
          <div className="card">
            <div className="card-body">
              <h5>{item.name}</h5>
              {Object.keys(item.params).map((paramName) => (
                <div className="form-group" key={paramName}>
                  <label>{paramName}</label>
                  <input
                    type="text"
                    value={item.params[paramName]}
                    onChange={(e) => onUpdateActionParams(index, paramName, e.target.value)}
                    className="form-control"
                    placeholder={getPlaceholderText(paramName)}
                  />
                </div>
              ))}
              <button className="btn btn-danger btn-sm mt-2" onClick={() => onRemoveAction(index)}>
                Sil
              </button>
            </div>
          </div>
        </div>
      )}
    </Draggable>
  );
};

export default DraggableItem;
