// frontend/src/components/ScenarioBuilder.js
import React, { useState } from 'react';
import { useDrop } from 'react-dnd';
import axios from 'axios';
import { DragDropContext } from 'react-beautiful-dnd';
import ActionList from './ActionList';
import ScenarioArea from './ScenarioArea';
import Tour from '@reactour/tour';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const ScenarioBuilder = () => {
  const [scenario, setScenario] = useState([]);
  const [isTourOpen, setIsTourOpen] = useState(true);
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);

  const actions = [
    { name: 'Sayfa Aç', type: 'goto', params: { url: '' } },
    // Diğer aksiyonları burada ekleyin
  ];

  const steps = [
    {
      selector: '.action-cards',
      content: 'Burada aksiyonları görebilirsiniz. Sürükleyip bırakın!',
    },
    {
      selector: '.scenario-area',
      content: 'Senaryonuzu oluşturmak için aksiyonları buraya sürükleyin.',
    },
    {
      selector: '.run-scenario-button',
      content: 'Senaryoyu çalıştırmak için bu düğmeyi kullanabilirsiniz!',
    },
  ];

  const [{ isOver }, drop] = useDrop(() => ({
    accept: 'ACTION',
    drop: (item) => addToScenario(item),
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  }));

  const addToScenario = (action) => {
    setScenario((prevScenario) => [...prevScenario, action]);
  };

  const removeAction = (index) => {
    setScenario((prevScenario) => prevScenario.filter((_, i) => i !== index));
  };

  const updateActionParams = (index, paramName, value) => {
    const updatedScenario = [...scenario];
    updatedScenario[index].params[paramName] = value;
    setScenario(updatedScenario);
  };

  const onDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination || source.index === destination.index) return;

    const updatedScenario = Array.from(scenario);
    const [movedAction] = updatedScenario.splice(source.index, 1);
    updatedScenario.splice(destination.index, 0, movedAction);

    setScenario(updatedScenario);
  };

  const runScenario = async () => {
    if (scenario.length === 0) {
      toast.error("Aksiyon Eklemedin! Lütfen en az bir aksiyon ekle.");
      return;
    }

    setIsRunning(true);
    setProgress(0);

    try {
      await axios.post('http://localhost:4000/run-script', { scenario });
      toast.success("Senaryo başarıyla tamamlandı!");
    } catch (error) {
      toast.error('Hata oluştu: ' + error.message);
    } finally {
      setIsRunning(false);
    }
  };

  const getPlaceholderText = (paramName) => {
    const placeholders = {
      url: 'https://example.com',
      selector: '.class-name veya #id',
      time: '1000 (milisaniye)',
      text: 'Metin girin',
      key: 'Enter, Escape, vb.',
      path: 'screenshot.png',
      x: 'Yatay kaydırma pikseli',
      y: 'Dikey kaydırma pikseli',
    };
    return placeholders[paramName] || 'Değer girin';
  };

  return (
    <div style={{ display: 'flex', height: '80vh', padding: '0px', boxSizing: 'border-box', maxWidth: "1000px !important" }}>
      <ToastContainer position="top-right" autoClose={5000} />

      <ActionList actions={actions} dropRef={drop} />
      
      <DragDropContext onDragEnd={onDragEnd}>
        <ScenarioArea
          scenario={scenario}
          onRemoveAction={removeAction}
          onUpdateActionParams={updateActionParams}
          getPlaceholderText={getPlaceholderText}
          isOver={isOver} // Sürükleme durumu
        />
      </DragDropContext>

      <div className="card-footer text-right">
        <button onClick={runScenario} className="btn btn-primary run-scenario-button" disabled={isRunning}>
          {isRunning ? "Çalışıyor..." : "Senaryoyu Çalıştır"}
        </button>
      </div>

      <Tour steps={steps} isOpen={isTourOpen} onRequestClose={() => setIsTourOpen(false)} />
    </div>
  );
};

export default ScenarioBuilder;
